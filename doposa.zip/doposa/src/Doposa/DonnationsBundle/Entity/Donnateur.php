<?php
// src/Sdz/BlogBundle/Entity/Donnateur.php
namespace Doposa\DonnationsBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
/**
* Doposa\DonnationsBundle\Entity\Donnateur
*
* @ORM\Table(name="doposa_Donnateur")
*
@ORM\Entity(repositoryClass="Doposa\DonnationsBundle\Entity\DonnateurRepository")
@ORM\Entity
*/
class Donnateur
{
  /**
  * @ORM\Column(name="id", type="integer")
  * @ORM\Id
  * @ORM\GeneratedValue(strategy="AUTO")
  */
    private $id;

    /**
  * @ORM\Column(name="date", type="date")
  */
    private $date;

    /**
  * @ORM\Column(name="raison", type="string", length=255)
  */
    private $raison;

    /**
  * @ORM\Column(name="donnateur", type="string", length=255)
  */
    private $donnateur;

    /**
  * @ORM\Column(name="somme", type="text")
  */
    private $somme;
   // Et bien sûr les getters/setters :

     public function __construct()
    {
      $this->date = new \Datetime();
      $this->publication = true;
    }
   public function setId($id)
   {
     $this->id = $id;
   }
   public function getId()
   {
     return $this->id;
   }
   public function setDate($date)
   {
     $this->date = $date;
   }
   public function getDate()
   {
     return $this->date;
   }
     public function setRaison($raison)
    {
      $this->raison = $raison;
    }
    public function getRaison()
    {
      return $this->raison;
    }
    public function setDonnateur($donnateur)
    {
      $this->donnateur = $donnateur;
    }
    public function getDonnateur()
    {
      return $this->donnateur;
    }
    public function setSomme($somme)
    {
      $this->somme = $somme;
    }
    public function getSomme()
    {
      return $this->somme;
    }

}
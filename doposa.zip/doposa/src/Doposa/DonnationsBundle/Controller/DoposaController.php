<?php

namespace Doposa\DonnationsBundle\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Doposa\DonnationsBundle\Entity\Donnateur;
class DoposaController extends Controller
{
    public function indexAction($name,$id)
    {
        $em = $this->getDoctrine()->getManager();
        if($id==0){//aucun profils affiche
            $donnates = $em->getRepository('DoposaDonnationBundle:Donnateur')->findAll();
            return $this->render('DoposaDonnationBundle:Doposa:index.html.twig', array('name' => -1,'id'=>$id, 'donnate'=>$donnates));
        }elseif ($id==-1) {//tous les dons du profils
            $donnates = $em->getRepository('DoposaDonnationBundle:Donnateur')->findAll();
            return $this->render('DoposaDonnationBundle:Doposa:index.html.twig', array('name' =>  $name,'id'=>$id, 'donnate'=>$donnates));
        }else{//un seul des dons du profils
            $donnates = $em->getRepository('DoposaDonnationBundle:Donnateur')->findAll();
            return $this->render('DoposaDonnationBundle:Doposa:index.html.twig', array('name' => 0,'id'=>$id ,'donnate'=>$donnates));
        }
    }
    public function testAction()
    {
        $em = $this->getDoctrine()->getManager();
        $donnates = $em->getRepository('DoposaDonnationBundle:Donnateur')->findAll();
         $mailer = $this->get('mailer');
            $message = \Swift_Message::newInstance()
              ->setSubject('Hello zéro !')
              ->setFrom('feavprograming@gmail.com')
              ->setTo('feavfeav@gmail.com')
              ->setBody('Coucou, voici un email que vous venez de recevoir!');
            $mailer->send($message);
        return $this->render('DoposaDonnationBundle:Doposa:test.html.twig', array('name'=>'feav','id'=>'2','donnate'=>$donnates));
    }
    public function donnateursAction()
    {
        $em = $this->getDoctrine()->getManager();
        $donnates = $em->getRepository('DoposaDonnationBundle:Donnateur')->findAll();
        return $this->render('DoposaDonnationBundle:Doposa:donnateurs.html.twig', array('donnate' => $donnates ));
    }
    public function contactAction()
    {   
        $em = $this->getDoctrine()->getManager();
        $donnates = $em->getRepository('DoposaDonnationBundle:Donnateur')->findAll();
        return $this->render('DoposaDonnationBundle:Doposa:contact.html.twig', array('donnate'=>$donnates));
    }
    public function donAction()
    {

        $em = $this->getDoctrine()->getManager();
        $donnates = $em->getRepository('DoposaDonnationBundle:Donnateur')->findAll();
        //http://localhost/doposa/web/app_dev.php/don/?valid=doposavalidDonnation&nom=toto&somme=12000&raison=tata
        $donnateur = new Donnateur();
        $accept = $this->getRequest()->query->get('valid');
        $donnateur->setDonnateur($this->getRequest()->query->get('nom'));
        $donnateur->setSomme($this->getRequest()->query->get('somme'));
        $donnateur->setRaison($this->getRequest()->query->get('raison'));
        $em = $this->getDoctrine()->getManager();
        $em->persist($donnateur);
        $em->flush();
        if($accept=="doposavalidDonnation" && $donnateur->getSomme()>1000){
            $mailer = $this->get('mailer');              
            $mesg = "Mr/Mme ".$donnateur->getDonnateur()." on vous remercie pour votre don de ".$donnateur->getSomme()." pour la renovation du pont de l enfance a sa'a";

            $message = \Swift_Message::newInstance()
              ->setSubject('Merci pour votre don a doposa!')
              ->setFrom('feavprograming@gmail.com')
              ->setTo($donnateur->getRaison())
              ->setBody( $mesg);
            $mailer->send($message);

            return $this->render('DoposaDonnationBundle:Doposa:don.html.twig', array('valid' => 1,'don'=>$donnateur, 'donnate'=>$donnateur));
        }else{
            return $this->render('DoposaDonnationBundle:Doposa:don.html.twig', array('don'=>$donnateur,'donnate' => $donnates ));
        }
    }
}


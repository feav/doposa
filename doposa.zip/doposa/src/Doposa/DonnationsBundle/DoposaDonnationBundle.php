<?php

namespace Doposa\DonnationsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DoposaDonnationBundle extends Bundle
{
}

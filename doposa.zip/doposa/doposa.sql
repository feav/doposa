-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Sam 02 Juillet 2016 à 13:17
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `doposa`
--

-- --------------------------------------------------------

--
-- Structure de la table `doposa_donnateur`
--

CREATE TABLE IF NOT EXISTS `doposa_donnateur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `raison` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `donnateur` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `somme` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

--
-- Contenu de la table `doposa_donnateur`
--

INSERT INTO `doposa_donnateur` (`id`, `date`, `raison`, `donnateur`, `somme`) VALUES
(1, '2016-06-20', 'robinsongeorges@gmail.com', 'Georges Robinson', '25000'),
(2, '2016-06-29', 'olivieratangana@gmail.com', 'Olivier Atangana', '10000'),
(3, '2016-06-14', 'bricetchinda@gmail.com', 'Brice Tchinda', '50000'),
(4, '2016-02-14', 'tatianadelaruche@gmail.com', 'Tatiana Delaruche', '5000'),
(9, '2016-07-02', 'feavfeav@gmail.com', 'EMBOLO Armel', '12000'),
(10, '2016-07-02', 'armelembolo@gmail.com', 'Fegue Embolo', '12000'),
(19, '2016-07-02', 'armelembolo@gmail.com', 'ARMEL EMBOLO', '12000'),
(20, '2016-07-02', 'feavfeav@gmail.com', 'fegue embolo', '123332'),
(21, '2016-07-02', 'feavfeav@gmail.com', 'fegue embolo', '123332');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

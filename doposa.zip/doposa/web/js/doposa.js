function viewDialog($id){
	var element = document.getElementById($id);
	var display = element.style.display;
	if(display=="none"){
		element.style.display = "block";
	}else{
		element.style.display = "none";
	}
}

function checkVerify(){
	var check = document.getElementById('checkFiel');
	var name = document.getElementById('nameFiel');
	var somme = document.getElementById('sommeFiel');
	var email = document.getElementById('emailFiel');
	if(name.value==""||somme.value==""||email.value==""){
		alert('Il y a encore des champs vides');
		check.checked =false;
		return 0;
	}
	if(check.checked){
		var val = parseInt(somme.value);
		if(val<1000){
			alert('Votre don doit avoir une valeur d\'au moins 1000FCFA');
			check.checked =false;
			somme.style.background="#f9afaf";
			somme.value = "";
			return 0;
		}
		var lien1 = document.getElementById('lien1');
		var lien2 = document.getElementById('lien2');
		var lien3 = document.getElementById('lien3');
		var lien = "http://localhost/doposa/web/app.php/don/?";
		var ouiVal = "valid=doposavalidDonnation&";
		var nonVal = "valid=doposavalidDonnations&";
		document.getElementById('euroFiel').value = parseInt(val/650);

		var info = "nom="+name.value+"&somme="+somme.value+"&raison="+email.value;


		lien1.value=lien+ouiVal+info;
		lien2.value=lien+nonVal+info;
		lien3.value=lien+ouiVal+info;
	}
}